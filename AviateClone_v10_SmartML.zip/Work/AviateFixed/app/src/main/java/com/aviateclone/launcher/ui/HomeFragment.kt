package com.aviateclone.launcher.ui

import android.app.Activity
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.*
import android.view.animation.OvershootInterpolator
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.aviateclone.launcher.adapter.AppGridAdapter
import com.aviateclone.launcher.data.AppInfo
import com.aviateclone.launcher.databinding.FragmentHomeBinding
import com.aviateclone.launcher.widget.WallpaperPaletteHelper
import java.text.SimpleDateFormat
import java.util.*

class HomeFragment : Fragment() {

    private var _b: FragmentHomeBinding? = null
    private val b get() = _b!!
    private val vm: LauncherViewModel by activityViewModels()

    private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val dateFmt = SimpleDateFormat("EEEE, d MMMM", Locale.ITALIAN)
    private val handler = Handler(Looper.getMainLooper())
    private val clockRunnable = object : Runnable {
        override fun run() { updateClock(); handler.postDelayed(this, 10_000) }
    }

    // Widget
    private lateinit var appWidgetManager: AppWidgetManager
    private lateinit var appWidgetHost: AppWidgetHost
    private val HOST_ID = 1024
    private val PREFS_WIDGETS = "aviate_widgets"
    private val KEY_IDS = "widget_ids"

    // Gesture
    private lateinit var gestureDetector: GestureDetector
    private lateinit var scaleDetector: ScaleGestureDetector
    private var pinchTriggered = false

    // Drag&drop preferiti
    private val favList = mutableListOf<AppInfo>()
    private lateinit var favAdapter: AppGridAdapter
    private lateinit var itemTouchHelper: ItemTouchHelper

    private val widgetPickLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode != Activity.RESULT_OK) return@registerForActivityResult
        val id = result.data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1) ?: -1
        if (id == -1) return@registerForActivityResult
        val info: AppWidgetProviderInfo? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            result.data?.getParcelableExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, AppWidgetProviderInfo::class.java)
        else @Suppress("DEPRECATION") result.data?.getParcelableExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER)
        if (info != null && !appWidgetManager.bindAppWidgetIdIfAllowed(id, info.provider))
            widgetBindLauncher.launch(Intent(AppWidgetManager.ACTION_APPWIDGET_BIND).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
            })
        else handlePostBind(id)
    }

    private val widgetBindLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val id = result.data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1) ?: -1
        if (result.resultCode == Activity.RESULT_OK && id != -1) handlePostBind(id)
        else if (id != -1) appWidgetHost.deleteAppWidgetId(id)
    }

    private val widgetConfigLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val id = result.data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1) ?: -1
        if (id == -1) return@registerForActivityResult
        if (result.resultCode == Activity.RESULT_OK) attachWidget(id) else appWidgetHost.deleteAppWidgetId(id)
    }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentHomeBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // ── Tema automatico basato su luminosità wallpaper ────────────────
        applyWallpaperTheme()

        updateClock()
        handler.post(clockRunnable)

        // GestureDetector: long press → wallpaper picker
        gestureDetector = GestureDetector(requireContext(),
            object : GestureDetector.SimpleOnGestureListener() {
                override fun onLongPress(e: MotionEvent) {
                    view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    (activity as? MainActivity)?.openWallpaperPicker()
                }
                override fun onDown(e: MotionEvent) = true
            })

        // ScaleGestureDetector: pinch → cassetto app
        scaleDetector = ScaleGestureDetector(requireContext(),
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScale(d: ScaleGestureDetector): Boolean {
                    if (!pinchTriggered && d.scaleFactor < 0.82f) {
                        pinchTriggered = true
                        view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                        (activity as? MainActivity)?.b?.viewPager?.setCurrentItem(3, true)
                    }
                    return true
                }
                override fun onScaleEnd(d: ScaleGestureDetector) { pinchTriggered = false }
            })

        b.root.setOnTouchListener { v, e ->
            scaleDetector.onTouchEvent(e)
            if (!scaleDetector.isInProgress) gestureDetector.onTouchEvent(e)
            if (e.action == MotionEvent.ACTION_UP) v.performClick()
            false
        }

        // ── App preferite con drag&drop ───────────────────────────────────
        favAdapter = AppGridAdapter(
            onAppClick = { app ->
                val idx = favList.indexOfFirst { it.packageName == app.packageName }
                val iconView = b.rvFavorites.layoutManager?.findViewByPosition(idx)
                view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                (activity as? MainActivity)?.launchAppFromView(app, iconView)
            }
        )
        b.rvFavorites.apply {
            adapter = favAdapter
            layoutManager = GridLayoutManager(requireContext(), 4)
            isNestedScrollingEnabled = false
        }

        // Drag&drop per riordinare i preferiti
        val touchCallback = object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT or
            ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0) {
            override fun onMove(rv: RecyclerView, from: RecyclerView.ViewHolder, to: RecyclerView.ViewHolder): Boolean {
                val fromPos = from.bindingAdapterPosition
                val toPos   = to.bindingAdapterPosition
                if (fromPos < 0 || toPos < 0 || fromPos >= favList.size || toPos >= favList.size) return false
                val item = favList.removeAt(fromPos)
                favList.add(toPos, item)
                favAdapter.submitList(favList.toList())
                return true
            }
            override fun onSwiped(h: RecyclerView.ViewHolder, d: Int) {}
            override fun onSelectedChanged(h: RecyclerView.ViewHolder?, actionState: Int) {
                super.onSelectedChanged(h, actionState)
                if (actionState == ItemTouchHelper.ACTION_STATE_DRAG)
                    h?.itemView?.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            }
        }
        itemTouchHelper = ItemTouchHelper(touchCallback)
        itemTouchHelper.attachToRecyclerView(b.rvFavorites)

        vm.allApps.observe(viewLifecycleOwner) { apps ->
            val top8 = apps.sortedByDescending { it.launchCount }.take(8)
            favList.clear(); favList.addAll(top8)
            favAdapter.submitList(favList.toList())
        }
        vm.badgeCounts.observe(viewLifecycleOwner) { favAdapter.updateBadges(it) }

        // Search bar
        b.searchBar.setOnClickListener {
            try {
                startActivity(Intent(Intent.ACTION_WEB_SEARCH).apply {
                    putExtra("query", "")
                    setPackage("com.google.android.googlequicksearchbox")
                })
            } catch (_: Exception) { try { startActivity(Intent(Intent.ACTION_WEB_SEARCH)) } catch (_: Exception) {} }
        }
        b.searchMic.setOnClickListener {
            try { startActivity(Intent("android.speech.action.WEB_SEARCH")) } catch (_: Exception) {}
        }

        // Widget host
        appWidgetManager = AppWidgetManager.getInstance(requireContext())
        appWidgetHost = AppWidgetHost(requireContext(), HOST_ID)
        appWidgetHost.startListening()
        restoreWidgets()

        b.btnAddWidget.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            it.animate().scaleX(0.88f).scaleY(0.88f).setDuration(80).withEndAction {
                it.animate().scaleX(1f).scaleY(1f).setDuration(130)
                    .setInterpolator(OvershootInterpolator()).start()
                pickWidget()
            }.start()
        }

        animateEntrance()
    }

    // ── Tema automatico da wallpaper ──────────────────────────────────────
    private fun applyWallpaperTheme() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O_MR1) return
        try {
            val isDark = WallpaperPaletteHelper.isDarkWallpaper(requireContext())
            val textColor = if (isDark) 0xFFFFFFFF.toInt() else 0xFF1C1B1F.toInt()
            val shadowColor = if (isDark) 0x66000000.toInt() else 0x33000000.toInt()
            _b?.tvTime?.apply {
                setTextColor(textColor)
                setShadowLayer(12f, 0f, 2f, shadowColor)
            }
            _b?.tvDate?.apply {
                setTextColor(if (isDark) 0xCCFFFFFF.toInt() else 0xCC1C1B1F.toInt())
                setShadowLayer(6f, 0f, 1f, shadowColor)
            }
        } catch (_: Exception) {}
    }



    private fun animateEntrance() {
        listOf(b.clockBlock, b.searchBar, b.rvFavorites, b.widgetSection)
            .forEachIndexed { i, v ->
                v.alpha = 0f; v.translationY = 50f
                v.animate().alpha(1f).translationY(0f)
                    .setStartDelay(60L + i * 80).setDuration(600)
                    .setInterpolator(OvershootInterpolator(1.1f)).start()
            }
    }

    // ── Widget ─────────────────────────────────────────────────────────────
    private fun pickWidget() {
        widgetPickLauncher.launch(Intent(AppWidgetManager.ACTION_APPWIDGET_PICK).apply {
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetHost.allocateAppWidgetId())
        })
    }
    private fun handlePostBind(id: Int) {
        val info = appWidgetManager.getAppWidgetInfo(id)
        if (info?.configure != null)
            widgetConfigLauncher.launch(Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE).apply {
                component = info.configure; putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            })
        else attachWidget(id)
    }
    private fun attachWidget(id: Int) {
        val info = appWidgetManager.getAppWidgetInfo(id) ?: return
        val dp = resources.displayMetrics.density
        val wv = appWidgetHost.createView(requireContext(), id, info)
        // FIX: sfondo trasparente — il widget usa i propri colori, non il container
        wv.setBackgroundColor(android.graphics.Color.TRANSPARENT)
        wv.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            (info.minHeight.coerceAtLeast(80) * dp).toInt()
        ).apply { bottomMargin = (8 * dp).toInt() }
        wv.setOnLongClickListener { removeWidget(id, wv); true }
        b.widgetContainer.addView(wv)
        b.widgetPlaceholder.visibility = View.GONE
        saveWidgetId(id)
    }
    private fun removeWidget(id: Int, view: AppWidgetHostView) {
        b.widgetContainer.removeView(view); appWidgetHost.deleteAppWidgetId(id); deleteWidgetId(id)
        if (b.widgetContainer.childCount == 0) b.widgetPlaceholder.visibility = View.VISIBLE
        Toast.makeText(requireContext(), "Widget rimosso", Toast.LENGTH_SHORT).show()
    }
    private fun prefs() = requireContext().getSharedPreferences(PREFS_WIDGETS, 0)
    private fun saveWidgetId(id: Int) {
        val ids = prefs().getStringSet(KEY_IDS, mutableSetOf())!!.toMutableSet()
        ids.add(id.toString()); prefs().edit().putStringSet(KEY_IDS, ids).apply()
    }
    private fun deleteWidgetId(id: Int) {
        val ids = prefs().getStringSet(KEY_IDS, mutableSetOf())!!.toMutableSet()
        ids.remove(id.toString()); prefs().edit().putStringSet(KEY_IDS, ids).apply()
    }
    private fun restoreWidgets() {
        prefs().getStringSet(KEY_IDS, emptySet())?.forEach { str ->
            val id = str.toIntOrNull() ?: return@forEach
            if (appWidgetManager.getAppWidgetInfo(id) != null) attachWidget(id)
            else { appWidgetHost.deleteAppWidgetId(id); deleteWidgetId(id) }
        }
        if (b.widgetContainer.childCount == 0) b.widgetPlaceholder.visibility = View.VISIBLE
    }

    private var lastTimeStr = ""
    private fun updateClock() {
        val now = Date()
        val newTime = timeFmt.format(now)
        if (newTime != lastTimeStr) {
            _b?.tvTime?.let { tv ->
                tv.animate().alpha(0f).setDuration(150).withEndAction {
                    tv.text = newTime; tv.animate().alpha(1f).setDuration(200).start()
                }.start()
            }
            lastTimeStr = newTime
        }
        _b?.tvDate?.text = dateFmt.format(now).replaceFirstChar { it.uppercase() }
    }

    override fun onResume() { super.onResume(); updateClock(); applyWallpaperTheme() }
    override fun onDestroyView() {
        super.onDestroyView()
        handler.removeCallbacks(clockRunnable)
        if (::appWidgetHost.isInitialized) appWidgetHost.stopListening()
        _b = null
    }
}
