package com.aviateclone.launcher.ui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.*
import android.view.animation.OvershootInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.GridLayoutManager
import com.aviateclone.launcher.R
import com.aviateclone.launcher.adapter.AppGridAdapter
import com.aviateclone.launcher.databinding.FragmentSmartStreamBinding
import com.aviateclone.launcher.engine.TimeContext
import com.google.android.material.bottomsheet.BottomSheetDialog
import java.text.SimpleDateFormat
import java.util.*

class SmartStreamFragment : Fragment() {

    private var _b: FragmentSmartStreamBinding? = null
    private val b get() = _b!!
    private val vm: LauncherViewModel by activityViewModels()

    private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val dateFmt = SimpleDateFormat("EEEE, d MMMM", Locale.ITALIAN)
    private val handler = Handler(Looper.getMainLooper())
    private val clockTick = object : Runnable {
        override fun run() { updateClock(); handler.postDelayed(this, 10_000) }
    }
    private var sysReceiver: BroadcastReceiver? = null

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentSmartStreamBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        b.statusBarSpacer.layoutParams.height = getStatusBarHeight()
        b.statusBarSpacer.requestLayout()

        // ── App suggerite (AppPredictionManager o scoring ML) ────────────
        val appsAdapter = AppGridAdapter(
            onAppClick = { app ->
                view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                (activity as? MainActivity)?.launchAppFromView(app, null)
            },
            textColorRes = Color.parseColor("#1C1B1F")
        )
        b.rvStreamApps.apply {
            adapter = appsAdapter
            layoutManager = GridLayoutManager(requireContext(), 4)
            isNestedScrollingEnabled = false
        }
        vm.suggestedApps.observe(viewLifecycleOwner) { appsAdapter.submitList(it.take(8)) }
        vm.badgeCounts.observe(viewLifecycleOwner) { appsAdapter.updateBadges(it) }

        // ── Contesto / header ─────────────────────────────────────────────
        vm.currentContext.observe(viewLifecycleOwner) { ctx ->
            updateHeader(ctx); buildModePills(ctx)
        }

        // ── AI Briefing ───────────────────────────────────────────────────
        vm.aiBriefing.observe(viewLifecycleOwner) { text ->
            if (!text.isNullOrBlank()) {
                b.cardAiBriefing?.visibility = View.VISIBLE
                b.tvAiBriefing?.text = text
                b.cardAiBriefing?.animate()?.alpha(1f)?.setDuration(600)?.start()
            } else {
                b.cardAiBriefing?.visibility = View.GONE
            }
        }

        // ── Notifica smart prioritizzata ──────────────────────────────────
        vm.topRankedNotif.observe(viewLifecycleOwner) { ranked ->
            if (ranked != null && ranked.score > 1.5f) {
                b.cardSmartNotif?.visibility = View.VISIBLE
                b.tvSmartNotifTitle?.text = ranked.title
                b.tvSmartNotifText?.text = if (ranked.reason.isNotBlank())
                    "${ranked.text.take(60)} · ${ranked.reason}" else ranked.text.take(80)
            } else {
                b.cardSmartNotif?.visibility = View.GONE
            }
        }

        // ── Routine rilevate ──────────────────────────────────────────────
        vm.patterns.observe(viewLifecycleOwner) { patterns ->
            if (patterns.isEmpty()) {
                b.cardPatterns?.visibility = View.GONE
                return@observe
            }
            b.cardPatterns?.visibility = View.VISIBLE
            b.llPatterns?.removeAllViews()
            val apps = vm.allApps.value ?: return@observe
            patterns.forEach { pattern ->
                val app = apps.firstOrNull { it.packageName == pattern.packageName } ?: return@forEach
                val row = LinearLayout(requireContext()).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = android.view.Gravity.CENTER_VERTICAL
                    setPadding(0, 6, 0, 6)
                }
                val icon = android.widget.ImageView(requireContext()).apply {
                    layoutParams = LinearLayout.LayoutParams(32, 32).apply { marginEnd = 10 }
                    setImageDrawable(app.icon)
                    scaleType = android.widget.ImageView.ScaleType.CENTER_INSIDE
                }
                val label = TextView(requireContext()).apply {
                    text = "${app.appName} — ${pattern.triggerDescription}"
                    setTextColor(Color.parseColor("#1C1B1F"))
                    textSize = 13f
                    typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                row.addView(icon); row.addView(label)
                row.setOnClickListener {
                    (activity as? MainActivity)?.launchAppFromView(app, icon)
                }
                b.llPatterns?.addView(row)
            }
        }

        // ── Weekly Digest ─────────────────────────────────────────────────
        vm.weeklyDigest.observe(viewLifecycleOwner) { digest ->
            if (digest != null) {
                b.cardWeeklyDigest?.visibility = View.VISIBLE
                b.tvWeeklyDigest?.text = digest.summary
            } else {
                b.cardWeeklyDigest?.visibility = View.GONE
            }
        }

        // ── Meteo reale ───────────────────────────────────────────────────
        vm.weather.observe(viewLifecycleOwner) { w ->
            if (w != null) {
                b.cardWeather.visibility = View.VISIBLE
                b.tvWeatherEmoji.text = w.emoji
                b.tvWeatherTemp.text = "${w.tempC}°"
                b.tvWeatherDesc.text = w.description
                b.tvWeatherFeels?.text = if (w.tempC != w.feelsLike) "Percepita ${w.feelsLike}°" else ""
            } else b.cardWeather.visibility = View.GONE
        }

        // ── Calendario ────────────────────────────────────────────────────
        vm.events.observe(viewLifecycleOwner) { events ->
            val next = events.firstOrNull { it.isSoon || it.isNow } ?: events.firstOrNull()
            if (next != null) {
                b.cardCalendar.visibility = View.VISIBLE
                b.tvEventTitle.text = next.title
                b.tvEventTime.text = when {
                    next.isNow  -> "● In corso"
                    next.isSoon -> "Tra poco — ${next.timeLabel}"
                    else        -> next.timeLabel
                }
            } else b.cardCalendar.visibility = View.GONE
        }

        // ── Chiamate perse / SMS ──────────────────────────────────────────
        vm.missedCalls.observe(viewLifecycleOwner) { calls ->
            b.cardMissedCalls?.visibility = if (calls.isEmpty()) View.GONE else View.VISIBLE
            b.tvMissedCallsCount?.text = when {
                calls.isEmpty() -> ""
                calls.size == 1 -> calls[0].name
                else -> "${calls.size} chiamate perse"
            }
        }
        vm.unreadSms.observe(viewLifecycleOwner) { sms ->
            b.cardUnreadSms?.visibility = if (sms.isEmpty()) View.GONE else View.VISIBLE
            b.tvUnreadSmsCount?.text = when {
                sms.isEmpty() -> ""
                sms.size == 1 -> "${sms[0].sender}: ${sms[0].snippet}"
                else -> "${sms.sumOf { it.count }} messaggi non letti"
            }
        }
        vm.isCarBluetooth.observe(viewLifecycleOwner) { isCar ->
            b.cardCarBt?.visibility = if (isCar) View.VISIBLE else View.GONE
        }

        // ── Cuffie / Musica ───────────────────────────────────────────────
        vm.headphones.observe(viewLifecycleOwner) { (on, name) ->
            b.cardHeadphones.visibility = if (on) View.VISIBLE else View.GONE
            if (on) b.tvHeadphonesName.text = name.ifBlank { "Connesse" }
        }
        vm.mediaPlaying.observe(viewLifecycleOwner) { media ->
            if (media != null) {
                b.cardMusic?.visibility = View.VISIBLE
                b.tvMusicTitle?.text = media.title
                b.tvMusicArtist?.text = media.artist
                b.btnMusicPlayPause?.text = if (media.isPlaying) "⏸" else "▶"
            } else b.cardMusic?.visibility = View.GONE
        }

        b.btnModeSelector.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            showContextPicker()
        }
        b.btnModeSelector.setOnLongClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            startActivity(android.content.Intent(requireContext(),
                GeminiSettingsActivity::class.java))
            true
        }

        updateClock(); updateBattery(); updateWifi()
        handler.post(clockTick)
        registerReceivers()
        animateEntrance()
    }

    private fun updateHeader(ctx: TimeContext) {
        b.tvModeEmoji.text = ctx.emoji
        val isManual = vm.contextEngine.isManualOverride()
        b.tvModeLabel.text = if (isManual) "${ctx.label} ✦" else ctx.label
        b.tvGreeting?.text = when (ctx) {
            com.aviateclone.launcher.engine.TimeContext.MORNING   -> "Buongiorno"
            com.aviateclone.launcher.engine.TimeContext.COMMUTE   -> "Buon viaggio"
            com.aviateclone.launcher.engine.TimeContext.WORK      -> "Buon lavoro"
            com.aviateclone.launcher.engine.TimeContext.LUNCH     -> "Buona pausa"
            com.aviateclone.launcher.engine.TimeContext.AFTERNOON -> "Buon pomeriggio"
            com.aviateclone.launcher.engine.TimeContext.EVENING   -> "Buonasera"
            com.aviateclone.launcher.engine.TimeContext.NIGHT     -> "Buonanotte"
        }
        b.tvSuggestedTitle.text = "PER ${ctx.label.uppercase()}"
        b.tvModeLabel.alpha = 0f; b.tvModeLabel.translationX = -20f
        b.tvModeLabel.animate().alpha(1f).translationX(0f)
            .setDuration(350).setInterpolator(OvershootInterpolator()).start()
    }

    private fun animateEntrance() {
        listOfNotNull<View>(b.btnModeSelector, b.cardWeather,
            b.rvStreamApps.parent as? View, b.sectionBattery, b.sectionWifi)
            .forEachIndexed { i, v ->
                v.alpha = 0f; v.translationY = 50f
                v.animate().alpha(1f).translationY(0f)
                    .setStartDelay(80L + i * 70).setDuration(580)
                    .setInterpolator(OvershootInterpolator(1.1f)).start()
            }
    }

    private fun buildModePills(current: TimeContext) {
        b.llModePills.removeAllViews()
        val dp = resources.displayMetrics.density
        val isManual = vm.contextEngine.isManualOverride()
        TimeContext.values().forEach { ctx ->
            val isActive = ctx == current
            val pill = TextView(requireContext()).apply {
                text = "${ctx.emoji}  ${ctx.label}"
                textSize = 12f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                background = ContextCompat.getDrawable(requireContext(),
                    if (isActive) R.drawable.bg_mode_pill else R.drawable.bg_mode_pill_outline)
                setTextColor(when {
                    isActive && isManual -> Color.parseColor("#FFD700")
                    isActive             -> Color.WHITE
                    else                 -> Color.parseColor("#CCFFFFFF")
                })
                val ph = (16 * dp).toInt(); val pv = (8 * dp).toInt()
                setPadding(ph, pv, ph, pv)
                layoutParams = ViewGroup.MarginLayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = (10 * dp).toInt() }
                setOnClickListener {
                    performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    animate().scaleX(0.88f).scaleY(0.88f).setDuration(80).withEndAction {
                        animate().scaleX(1f).scaleY(1f).setDuration(120)
                            .setInterpolator(OvershootInterpolator()).start()
                        vm.setManualContext(if (isActive && isManual) null else ctx)
                    }.start()
                }
            }
            b.llModePills.addView(pill)
        }
    }

    private fun showContextPicker() {
        val sheet = BottomSheetDialog(requireContext())
        val v = layoutInflater.inflate(R.layout.dialog_context_picker, null)
        sheet.setContentView(v)
        mapOf(
            R.id.itemMorning to TimeContext.MORNING, R.id.itemCommute to TimeContext.COMMUTE,
            R.id.itemWork to TimeContext.WORK,       R.id.itemLunch to TimeContext.LUNCH,
            R.id.itemEvening to TimeContext.EVENING, R.id.itemNight to TimeContext.NIGHT
        ).forEach { (id, ctx) ->
            v.findViewById<View>(id)?.setOnClickListener { vm.setManualContext(ctx); sheet.dismiss() }
        }
        v.findViewById<View>(R.id.itemAuto)?.setOnClickListener {
            vm.setManualContext(null); sheet.dismiss()
        }
        sheet.show()
    }

    private fun updateClock() {
        val now = Date()
        _b?.tvStreamTime?.text = timeFmt.format(now)
        _b?.tvStreamDate?.text = dateFmt.format(now).replaceFirstChar { it.uppercase() }
    }

    private fun updateBattery() {
        try {
            val i = requireContext().registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scl = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            if (lvl >= 0 && scl > 0) {
                val pct = (lvl * 100f / scl).toInt()
                _b?.tvBatteryLevel?.text = "$pct%"
                _b?.tvBatteryLevel?.setTextColor(when {
                    pct <= 20 -> Color.parseColor("#C62828")
                    pct >= 80 -> Color.parseColor("#1B7B45")
                    else      -> Color.parseColor("#49454F")
                })
            }
        } catch (_: Exception) {}
    }

    private fun updateWifi() {
        try {
            val ctx = context ?: return
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            when {
                caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> {
                    @Suppress("DEPRECATION")
                    val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                    var ssid = wm.connectionInfo.ssid.replace("\"", "")
                    if ((ssid.isBlank() || ssid == "<unknown ssid>") &&
                        Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                        ssid = (caps.transportInfo as? WifiInfo)?.ssid?.replace("\"","") ?: ssid
                    _b?.tvWifiName?.text = if (ssid.isNotBlank() && ssid != "<unknown ssid>") ssid else "Wi-Fi"
                    _b?.tvWifiName?.setTextColor(Color.parseColor("#1565C0"))
                }
                caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> {
                    _b?.tvWifiName?.text = "Dati mobili"
                    _b?.tvWifiName?.setTextColor(Color.parseColor("#1565C0"))
                }
                else -> {
                    _b?.tvWifiName?.text = "Offline"
                    _b?.tvWifiName?.setTextColor(Color.parseColor("#C62828"))
                }
            }
        } catch (_: Exception) { _b?.tvWifiName?.text = "—" }
    }

    private fun registerReceivers() {
        sysReceiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) { updateBattery(); updateWifi() }
        }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED)
            @Suppress("DEPRECATION") addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        }
        requireContext().registerReceiver(sysReceiver, f)
    }

    private fun getStatusBarHeight(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else 60
    }

    override fun onResume() { super.onResume(); updateClock(); updateBattery(); updateWifi() }
    override fun onDestroyView() {
        super.onDestroyView()
        handler.removeCallbacks(clockTick)
        sysReceiver?.let { try { requireContext().unregisterReceiver(it) } catch (_: Exception) {} }
        _b = null
    }
}
